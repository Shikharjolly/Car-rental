//
//  CarConfirmation2.swift
//  hbcarrental.4900project
//
//  Created by Shikhar Jolly on 5/11/24.
//

import SwiftUI

struct AddOnOption: Identifiable {
    let id = UUID()
    let name: String
    let price: Double
}

struct CarConfirmation: View {
    @State private var total: Double = 0.0
    var car: Car
    var addOnOptions: [AddOnOption] = [
        AddOnOption(name: "Personal driver", price: 8.90),
        AddOnOption(name: "Loss coverage waiver", price: 9.95),
        AddOnOption(name: "Full loss coverage waiver", price: 25.0),
        AddOnOption(name: "Additional driver", price: 2.0),
        AddOnOption(name: "Child seat", price: 19.0)
    ]
    
    var body: some View {
        ScrollView {
            VStack {
                Image(car.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Text(car.name)
                    .font(.largeTitle)
                    .bold()
                Text(car.type)
                    .font(.body)
                    .padding()
                VStack {
                    ForEach(addOnOptions) { option in
                        HStack {
                            Text(option.name)
                            Spacer()
                            Text("\(option.price, specifier: "%.2f")")
                            Button(action: {
                                total += option.price
                            }) {
                                Text("Add")
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }
                        }
                    }
                }
                Text("Total: \(total, specifier: "%.2f")")
                    .font(.title)
                    .bold()
                    .padding()
                Button(action: {
                    // Handle proceed button tap
                }) {
                    Text("Proceed")
                        .font(.title)
                        .bold()
                        .padding(5)
                        .background(Color.yellow)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                }
            }
        }

    }
    
    struct CarConfirmation_Previews: PreviewProvider {
        static var previews: some View {
            CarConfirmation(car: carDatabase[3])
        }
    }
}
