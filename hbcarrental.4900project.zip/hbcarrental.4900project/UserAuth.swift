//  UserAuth.swift
//  hbcarrental.4900project
//
//  Created by Ayrat Aymetov on 4/26/24.

import Combine

class UserAuth: ObservableObject {
    @Published var isLoggedin = false
}
